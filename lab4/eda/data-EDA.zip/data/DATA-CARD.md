# Паспорт локальных данных

Эти фиксированные копии нужны только для офлайн-выполнения ноутбука
`exploratory-data-analysis-python-only.ipynb`. Они получены из открытого
репозитория с исходным кодом примеров, коммит
`8a6d3bb6468e979c861d4b37215e1413702dfdfa`. Исходный репозиторий опубликован
по лицензии GNU GPL-3.0; её текст находится в `LICENSE-GPL-3.0.txt`.

Источник: <https://github.com/gedeck/practical-statistics-for-data-scientists>

| Файл | Строки × столбцы | Назначение | SHA-256 |
|---|---:|---|---|
| `state.csv` | 50 × 4 | Население и уровень убийств по штатам | `b8c53e8c8c093ff9c7f1b3c455df84cc6af2d99c16630abc2cc7a1789935eded` |
| `airline_stats.csv` | 33 468 × 4 | Доли причин задержки рейсов | `0bee622e10934163281e274a4a1730a8b98796c0290b92e7bbb6c82687bb05a6` |
| `dfw_airline.csv` | 1 × 5 | Причины задержек в аэропорту Даллас/Форт-Уэрт | `16472920ad17783e14f5654715b4e8c174d6720f05d6870a30934f02974387e4` |
| `kc_tax.csv.gz` | 498 249 × 3 | Оценочная стоимость жилья, площадь и почтовый индекс | `40fcfd77860a2ac8c62f8633e5937ee4acddded088095f3c144d46b8977dec7d` |
| `lc_loans.csv` | 450 961 × 2 | Уровень и состояние ссуд | `ecd25628adbb10713ff83c5c98317e99ee42ddc5f017a92f10cfef9b3a94de0e` |
| `sp500_data.csv.gz` | 5 647 × 519 | Временные ряды цен акций и ETF | `fb86ce1a70897800bee406a3c004254a731231041bb17aa4624e5fc3ab31cea7` |
| `sp500_sectors.csv` | 517 × 4 | Сектора и тикеры ценных бумаг | `d4cfd1329b16aa5cbab7aeaaadbed2e21c0e78835d39aeb58abc58f1762cc337` |

Для `sp500_data.csv.gz` число столбцов включает индекс дат, который при чтении
становится индексом кадра данных. Хеши относятся к точным файлам, включая
сжатие `.gz`.

## Схемы

- `state.csv`: `State` (строка), `Population` (целое), `Murder.Rate`
  (вещественное), `Abbreviation` (строка).
- `airline_stats.csv`: `pct_carrier_delay`, `pct_atc_delay`,
  `pct_weather_delay` (вещественные) и `airline` (строка).
- `dfw_airline.csv`: вещественные `Carrier`, `ATC`, `Weather`, `Security`,
  `Inbound`.
- `kc_tax.csv.gz`: вещественные `TaxAssessedValue`, `ZipCode` и целое
  `SqFtTotLiving`.
- `lc_loans.csv`: строковые `status` и `grade`.
- `sp500_data.csv.gz`: индекс дат и 518 вещественных столбцов с тикерами.
- `sp500_sectors.csv`: строковые `sector`, `sector_label`, `sub_sector`,
  `symbol`.
